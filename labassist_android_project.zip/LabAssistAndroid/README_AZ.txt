LABASSIST ANDROID LAYIHSI — V0.4

Bu qovluq Android Studio/Gradle ilə APK qurmaq üçün mənbə layihəsidir. Bu ZIP-in özü APK deyil.
Tətbiq LabAssist-in HTML prototipini Android WebView daxilində, internet tələb etmədən açır.

APK yaratmağın ən rahat texniki yolu:
1. Bu layihəni GitHub-da yeni repository-yə yüklə (bütün fayl və qovluqları saxla).
2. Repository-də Actions bölməsini aç.
3. “Build LabAssist APK” workflow-nu seçib “Run workflow” bas.
4. Build tamamlananda “LabAssist-debug-apk” artifact-ını yüklə və ZIP-dən çıxart.
5. app-debug.apk faylını Android telefona göndərib aç. Telefon kənar mənbədən quraşdırma icazəsi istəyə bilər.

Alternativ: Android Studio-da bu qovluğu aç və Build > Build APK(s) seç.

QEYD: Bu, debug APK olacaq, Play Store üçün imzalanmış buraxılış deyil. Analiz, cihaz, reaktiv və referens məlumatları tədris prototipidir; real laboratoriyanın SOP-ları ilə yoxlanmalıdır.
